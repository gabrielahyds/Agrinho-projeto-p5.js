let truck;

let campoItems = [];

let cidadeItems = [];

let score = 0;

let level = 1;

let delivering = false;

function setup() {

  createCanvas(800, 400);

  truck = createVector(100, height / 2);

  generateCampoItems();

}

function draw() {

  background(220);

  drawField();

  drawCity();

  drawTruck();

  if (!delivering) {

    for (let i = campoItems.length - 1; i >= 0; i--) {

      let item = campoItems[i];

      fill(0, 200, 0);

      ellipse(item.x, item.y, 20, 20);

      if (dist(truck.x, truck.y, item.x, item.y) < 20) {

        campoItems.splice(i, 1);

        delivering = true;

      }

    }

  } else {

    fill(255, 215, 0);

    ellipse(width - 100, height / 2, 40, 40);

    if (dist(truck.x, truck.y, width - 100, height / 2) < 30) {

      delivering = false;

      score++;

      if (score % 3 == 0) {

        level++;

      }

      generateCampoItems();

    }

  }

  moveTruck();

  drawHUD();

}

function drawField() {

  fill(144, 238, 144);

  rect(0, 0, width / 2, height);

  textAlign(CENTER);

  fill(0);

  textSize(16);

  text("🌾 Campo", width / 4, 30);

}

function drawCity() {

  fill(173, 216, 230);

  rect(width / 2, 0, width / 2, height);

  fill(0);

  text("🏙️ Cidade", 3 * width / 4, 30);

}

function drawTruck() {

  fill(150);

  rect(truck.x - 20, truck.y - 10, 40, 20);

  fill(0);

  ellipse(truck.x - 15, truck.y + 10, 10);

  ellipse(truck.x + 15, truck.y + 10, 10);

}

function moveTruck() {

  if (keyIsDown(LEFT_ARROW)) truck.x -= 3;

  if (keyIsDown(RIGHT_ARROW)) truck.x += 3;

  if (keyIsDown(UP_ARROW)) truck.y -= 3;

  if (keyIsDown(DOWN_ARROW)) truck.y += 3;

  truck.x = constrain(truck.x, 0, width);

  truck.y = constrain(truck.y, 0, height);

}

function generateCampoItems() {

  campoItems = [];

  for (let i = 0; i < level + 2; i++) {

    campoItems.push(createVector(random(50, width / 2 - 50), random(100, height - 50)));

  }

}

function drawHUD() {

  fill(0);

  textSize(16);

  textAlign(LEFT);

  text(`Pontuação: ${score}`, 10, 20);

  text(`Nível: ${level}`, 10, 40);

}

